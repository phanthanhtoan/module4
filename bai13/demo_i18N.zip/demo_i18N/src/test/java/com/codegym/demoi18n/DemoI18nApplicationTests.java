package com.codegym.demoi18n;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoI18nApplicationTests {

    @Test
    void contextLoads() {
    }

}
